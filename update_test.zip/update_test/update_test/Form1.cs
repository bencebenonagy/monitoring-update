using System;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace update_test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            string updaterPath = @"C:\Users\Public\net8.0\Updater.exe";
            string targetFolder = Application.StartupPath;
            string githubZipUrl = "https://github.com/bencebenonagy/monitoring-update/raw/refs/heads/main/net8.0-windows.zip";
            string mainExeName = "update_test.exe";
            string mainProcessName = Path.GetFileNameWithoutExtension(mainExeName); // e.g. "YourMainApp"

            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = updaterPath,
                Arguments = $"\"{targetFolder}\" \"{githubZipUrl}\" \"{mainExeName}\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            };

            try
            {
                // Close main app if running
                var runningProcesses = Process.GetProcessesByName(mainProcessName);
                foreach (var proc in runningProcesses)
                {
                    proc.CloseMainWindow(); // polite request to close
                    if (!proc.WaitForExit(5000)) // wait up to 5 seconds for graceful exit
                    {
                        proc.Kill(); // force kill if not closed
                        proc.WaitForExit();
                    }
                }

                // Start updater.exe with arguments
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = updaterPath,
                    Arguments = $"\"{targetFolder}\" \"{githubZipUrl}\" \"{mainExeName}\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                };

                using (Process process = Process.Start(psi))
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    if (!string.IsNullOrEmpty(output))
                        MessageBox.Show(output, "Update Output");

                    if (!string.IsNullOrEmpty(error))
                        MessageBox.Show(error, "Update Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during update: " + ex.Message);
            }
        }
    }
}