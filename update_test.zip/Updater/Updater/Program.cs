﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Updater will start in 5 seconds...");
        Thread.Sleep(5000);

        if (args.Length < 3)
        {
            Console.WriteLine("Error: Missing arguments.");
            Console.WriteLine("Usage: updater.exe <targetFolder> <githubZipUrl> <mainExeName>");
            return;
        }

        string targetFolder = args[0];
        string githubZipUrl = args[1];
        string mainExeName = args[2];

        if (!Directory.Exists(targetFolder))
        {
            Console.WriteLine($"Error: Target folder does not exist: {targetFolder}");
            return;
        }

        string mainSoftwareExe = Path.Combine(targetFolder, mainExeName);
        if (!File.Exists(mainSoftwareExe))
        {
            Console.WriteLine($"Warning: Main executable not found at {mainSoftwareExe}");
        }

        string tempZipFile = Path.Combine(Path.GetTempPath(), "update.zip");

        try
        {
            Console.WriteLine("Starting update...");

            DownloadZip(githubZipUrl, tempZipFile);
            ExtractZipOverwrite(tempZipFile, targetFolder);
            RestartMainApp(mainSoftwareExe);

            Console.WriteLine("Update complete.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Update failed: " + ex.Message);
        }
    }

    static void DownloadZip(string url, string zipPath)
    {
        Console.WriteLine("Downloading update package...");
        using (WebClient wc = new WebClient())
        {
            wc.DownloadFile(url, zipPath);
        }
        Console.WriteLine("Download finished.");
    }

    static void ExtractZipOverwrite(string zipPath, string targetFolder)
    {
        Console.WriteLine("Extracting update package...");

        string tempExtractFolder = Path.Combine(Path.GetTempPath(), "update_temp");
        if (Directory.Exists(tempExtractFolder))
            Directory.Delete(tempExtractFolder, true);

        ZipFile.ExtractToDirectory(zipPath, tempExtractFolder);

        string extractedSubFolder = Directory.GetDirectories(tempExtractFolder)[0];

        CopyAll(new DirectoryInfo(extractedSubFolder), new DirectoryInfo(targetFolder));

        Directory.Delete(tempExtractFolder, true);
        File.Delete(zipPath);

        Console.WriteLine("Extraction and overwrite done.");
    }

    static void CopyAll(DirectoryInfo source, DirectoryInfo target)
    {
        if (!target.Exists)
        {
            target.Create();
            target.Attributes = source.Attributes;
        }

        foreach (FileInfo fi in source.GetFiles())
        {
            string targetFilePath = Path.Combine(target.FullName, fi.Name);
            fi.CopyTo(targetFilePath, true);
        }

        foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
        {
            DirectoryInfo nextTargetSubDir = target.CreateSubdirectory(diSourceSubDir.Name);
            CopyAll(diSourceSubDir, nextTargetSubDir);
        }
    }

    static void RestartMainApp(string mainExePath)
    {
        if (!File.Exists(mainExePath))
        {
            Console.WriteLine("Main application executable not found, skipping restart.");
            return;
        }

        Console.WriteLine("Restarting main application...");

        ProcessStartInfo psi = new ProcessStartInfo
        {
            FileName = mainExePath,
            UseShellExecute = true
        };

        Process.Start(psi);

        Thread.Sleep(2000);
    }
}
